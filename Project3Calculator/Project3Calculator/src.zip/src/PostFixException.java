
public class PostFixException extends Exception
{
	private static final long serialVersionUID = -2841177442197768211L;

	public PostFixException()
	{
		super();
	}
	
	public PostFixException(String message)
	{
		super(message);
	}
}