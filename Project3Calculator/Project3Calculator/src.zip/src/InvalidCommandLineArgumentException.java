
public class InvalidCommandLineArgumentException extends Exception
{
	private static final long serialVersionUID = 4206905024044486860L;

	public InvalidCommandLineArgumentException ()
	{super();}
	
	public InvalidCommandLineArgumentException (String s)
	{super(s);}
}
